Uses a make file for ease of compilation
Standard command is make all
